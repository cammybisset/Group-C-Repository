package com.napier.sem;

public class App
{
    public static void main(String[] args)
    {
        System.out.println("Boo yah!");
    }
}
